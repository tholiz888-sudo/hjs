@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto folder_error
title Yini Capture
 echo Yini public-page capture - startup check
 echo Please keep this window open.
if not exist "capture.mjs" goto extract_error
if not exist "launch.mjs" goto extract_error
where node >nul 2>nul
if errorlevel 1 goto node_error
node --version
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 24 ? 0 : 1)"
if errorlevel 1 goto node_error
where curl.exe >nul 2>nul
if errorlevel 1 goto curl_error
node launch.mjs
 echo.
 echo Finished. Check capture.log and the output folder.
 pause
 exit /b
:extract_error
 echo ERROR: Extract ALL files from the ZIP first. Do not run inside the ZIP.
 goto done
:node_error
 echo ERROR: Install Node.js 24 or newer from https://nodejs.org/
 echo Close this window and open START.cmd again after installation.
 goto done
:curl_error
 echo ERROR: curl.exe was not found. Please send a screenshot of this window.
 goto done
:folder_error
 echo ERROR: Cannot open the tool folder. Extract it to a local folder first.
:done
 echo.
 pause
 exit /b 1

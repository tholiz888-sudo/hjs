import fs from 'node:fs/promises';
import path from 'node:path';

// Keep the previous manifest intact when Windows temporarily locks its name.
export function createCheckpointStore(file,{io=fs,wait=ms=>new Promise(r=>setTimeout(r,ms)),pid=process.pid}={}){
 let sequence=0;
 const basename=path.basename(file),directory=path.dirname(file);
 const isTemporary=name=>name===basename+'.tmp'||new RegExp('^'+basename.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\.\\d+\\.[01]\\.tmp$').test(name);
 async function read(){
  const candidates=[];
  for(const name of await io.readdir(directory)){
   if(name!==basename&&!isTemporary(name))continue;
   try{const full=path.join(directory,name),data=JSON.parse(await io.readFile(full,'utf8'));if(!data||typeof data.start!=='string'||!Array.isArray(data.records)||!Array.isArray(data.pending))continue;const stat=await io.stat(full);candidates.push({data,file:full,time:Date.parse(data.at)||stat.mtimeMs})}catch{}
  }
  candidates.sort((a,b)=>b.time-a.time);
  return candidates[0]||null;
 }
 async function write(data){
  const temporary=`${file}.${pid}.${sequence++%2}.tmp`;
  await io.writeFile(temporary,JSON.stringify(data,null,2));
  for(let attempt=0;attempt<6;attempt++){
   try{await io.rename(temporary,file);return{published:true,file}}
   catch(error){if(!['EPERM','EACCES','EBUSY','EEXIST'].includes(error.code))throw error;if(attempt<5)await wait(Math.min(100*2**attempt,800))}
  }
  // The complete temporary copy is also a valid recovery point on next launch.
  return{published:false,file:temporary};
 }
 return{read,write};
}

import {loadArchive} from './archive.mjs';
const archive=loadArchive();console.log(JSON.stringify(archive.stats,null,2));
for(const route of ['/','/club/garden.html'])if(!archive.pages.get(route)?.available)throw Error('Missing core page: '+route);
console.log('Core pages available. This is a partial archive until the complete original folder is imported.');

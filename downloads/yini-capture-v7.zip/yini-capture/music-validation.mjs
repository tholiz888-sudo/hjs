export function validateMp3(buffer,{status,type='',contentRange=''}={}){
 if(![200,206].includes(status))return{ok:false,reason:`HTTP ${status}`};
 if(!/^audio\/(?:mpeg|mp3)(?:;|$)/i.test(type.trim()))return{ok:false,reason:'返回的不是MP3音频类型：'+type};
 if(buffer.length<1024||/<(?:!doctype|html|head|body)\b/i.test(buffer.subarray(0,512).toString('latin1')))return{ok:false,reason:'返回的是提示页或音频文件过小'};
 const signature=buffer.subarray(0,3).toString('ascii')==='ID3'||(buffer[0]===255&&(buffer[1]&224)===224&&(buffer[1]&6)!==0);
 if(!signature)return{ok:false,reason:'未检测到MP3文件头，未保存为成功音频'};
 if(status===206){const match=contentRange.match(/^bytes\s+(\d+)-(\d+)\/(\d+)$/i);if(!match||Number(match[1])!==0||Number(match[2])+1!==Number(match[3])||buffer.length!==Number(match[3]))return{ok:false,reason:'只收到部分音频，不能作为完整文件保存'}}
 return{ok:true};
}

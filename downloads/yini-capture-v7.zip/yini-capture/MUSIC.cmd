@echo off
setlocal
cd /d "%~dp0"
echo Recover missing MP3 files. Do not run other capture windows at the same time.
node music.mjs
echo.
echo Check output\music-report.json for the result.
pause

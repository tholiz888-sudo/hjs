@echo off
setlocal
cd /d "%~dp0"
echo Test one song only. Keep the existing output folder here.
node music.mjs --one
echo.
echo Check output\music-report.json for the result.
pause

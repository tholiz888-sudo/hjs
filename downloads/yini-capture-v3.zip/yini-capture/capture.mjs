import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const run=promisify(execFile),root=path.dirname(fileURLToPath(import.meta.url));
const start=new URL(process.argv[2]||'http://www.yini.org/');
if(!['http:','https:'].includes(start.protocol))throw Error('只支持公开 HTTP/HTTPS 页面');
const max=Math.min(10000,Math.max(1,Number(process.env.CAPTURE_MAX_FILES)||5000));
const out=path.join(root,'output'),site=path.join(out,'site'),raw=path.join(out,'original');
await fs.mkdir(site,{recursive:true});await fs.mkdir(raw,{recursive:true});
const allowed=new Set([start.hostname,start.hostname.startsWith('www.')?start.hostname.slice(4):'www.'+start.hostname]);
const queue=[],known=new Set(),records=[],robots=new Map();let total=0,stopped=false,consecutiveFailures=0,stopReason='',limitReached=false;const processed=new Set();
const sleep=()=>new Promise(r=>setTimeout(r,800));
const entity=s=>s.replace(/&amp;/gi,'&').replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).replace(/&quot;/gi,'"');
function normalize(value,base){try{const u=new URL(entity(value.trim()),base);u.hash='';if(!['http:','https:'].includes(u.protocol)||u.username||u.password)return null;return u}catch{return null}}
function name(u){if(u.href===start.href)return'index.html';let ext=path.posix.extname(u.pathname).toLowerCase();if(!/^\.[a-z0-9]{1,8}$/.test(ext)||['.asp','.aspx','.php','.jsp','.cgi'].includes(ext))ext='.html';return createHash('sha256').update(u.href).digest('hex').slice(0,24)+ext}
function add(u){if(!u||!allowed.has(u.hostname)||known.has(u.href))return;if(known.size>=max){limitReached=true;return;}if(/\/(?:logout|delete|admin|login|register)(?:[/.?]|$)/i.test(u.pathname))return;known.add(u.href);queue.push(u)}
async function request(u,target){const h=target+'.headers';const args=['--silent','--show-error','--connect-timeout','12','--max-time','45','--max-filesize','20971520','--dump-header',h,'--output',target,'--user-agent','PublicPageArchive/1.0 (personal public-page archive)',u.href];if(process.env.CAPTURE_PROXY)args.unshift('--proxy',process.env.CAPTURE_PROXY);try{await run(process.platform==='win32'?'curl.exe':'curl',args,{maxBuffer:1024*1024,windowsHide:true});const header=await fs.readFile(h,'utf8');const blocks=header.trim().split(/\r?\n\r?\n/);const block=blocks.at(-1);const status=Number(block.match(/^HTTP\/\S+\s+(\d+)/i)?.[1]);return{status,type:block.match(/^content-type:\s*(.+)/im)?.[1]?.trim()||'',location:block.match(/^location:\s*(.+)/im)?.[1]?.trim()}}finally{await fs.rm(h,{force:true})}}
function rulesFor(text){const groups=[];let agents=[],rules=[],hasRules=false;const flush=()=>{if(agents.length)groups.push({agents:[...agents],rules:[...rules]});agents=[];rules=[];hasRules=false};for(const rawLine of text.split(/\r?\n/)){const line=rawLine.split('#')[0].trim(),i=line.indexOf(':');if(i<0)continue;const field=line.slice(0,i).toLowerCase(),value=line.slice(i+1).trim();if(field==='user-agent'){if(hasRules)flush();agents.push(value.toLowerCase())}else if((field==='allow'||field==='disallow')&&agents.length){hasRules=true;if(value)rules.push({allow:field==='allow',value})}}flush();const specific=groups.filter(g=>g.agents.some(a=>a!=='*'&&'publicpagearchive'.includes(a)));return(specific.length?specific:groups.filter(g=>g.agents.includes('*'))).flatMap(g=>g.rules)}
async function permitted(u){if(!robots.has(u.origin)){const file=path.join(out,'robots-'+robots.size+'.txt');await sleep();try{const r=await request(new URL('/robots.txt',u),file);if(r.status===401||r.status===403||r.status===429||r.status>=500){robots.set(u.origin,null);console.log('robots.txt 无法授权访问，跳过该站点：',u.origin)}else if(r.status>=300&&r.status<400){robots.set(u.origin,null);console.log('robots.txt 发生跳转，暂停该站点以待人工确认：',u.origin)}else robots.set(u.origin,r.status===200?rulesFor(await fs.readFile(file,'utf8')):[])}catch{robots.set(u.origin,null);console.log('无法读取 robots.txt，请检查网络后重试：',u.origin)}}const rules=robots.get(u.origin);if(rules===null)return false;const p=u.pathname+u.search;let chosen=null;for(const rule of rules){const end=rule.value.endsWith('$');const pattern=rule.value.replace(/\$$/,'').split('*').map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('.*');if(new RegExp('^'+pattern+(end?'$':'')).test(p)&&(!chosen||rule.value.length>chosen.value.length||rule.value.length===chosen.value.length&&rule.allow))chosen=rule}return!chosen||chosen.allow}
function decode(buffer,type){const head=buffer.subarray(0,8192).toString('latin1');const encoding=type.match(/charset\s*=\s*["']?([\w-]+)/i)?.[1]||head.match(/charset\s*=\s*["']?([\w-]+)/i)?.[1]||'utf-8';try{return new TextDecoder(encoding).decode(buffer)}catch{return buffer.toString('utf8')}}
function transform(text,u,html){let base=u;if(html){const b=text.match(/<base\b[^>]*href\s*=\s*["']([^"']+)["']/i);base=normalize(b?.[1]||'',u)||u;text=text.replace(/<base\b[^>]*>/gi,'')}const link=value=>{if(!value||value.startsWith('#')||/^(?:data:|javascript:|mailto:|tel:)/i.test(value))return value;const resolved=normalize(value,base);if(!resolved)return value;if(allowed.has(resolved.hostname)){add(resolved);const hash=new URL(entity(value),base).hash;return './'+name(resolved)+hash}return new URL(entity(value),base).href};if(html){text=text.replace(/\b(href|src|background|poster)\s*=\s*(["'])(.*?)\2/gi,(_,attr,q,value)=>`${attr}=${q}${link(value)}${q}`);text=text.replace(/\b(href|src|background|poster)\s*=\s*([^\s"'=<>`]+)/gi,(_,attr,value)=>`${attr}="${link(value)}"`);text=text.replace(/<meta\b[^>]*charset[^>]*>/gi,'');text='<meta charset="utf-8">\n'+text}text=text.replace(/url\(\s*(["']?)([^)'"\s]+)\1\s*\)/gi,(_,q,value)=>`url('${link(value)}')`);if(!html)text=text.replace(/@import\s+(["'])([^"']+)\1/gi,(_,q,value)=>`@import "${link(value)}"`);return text}
const manifestPath=path.join(out,'manifest.json');
let previous=null;try{previous=JSON.parse(await fs.readFile(manifestPath,'utf8'))}catch{}
if(previous&&previous.start!==start.href)throw Error('output中已有其他网站的采集记录，请先将output改名，避免混合不同站点。');
const cached=new Map((previous?.records||[]).map(r=>[r.url,r]));records.push(...(previous?.records||[]));
function remember(record){const index=records.findIndex(r=>r.url===record.url);if(index<0)records.push(record);else records[index]=record;processed.add(record.url)}
async function checkpoint(){const body={version:3,start:start.href,at:new Date().toISOString(),maxFiles:max,bytes:total,stopped,stopReason,limitReached,records,pending:queue.filter(u=>!processed.has(u.href)).map(u=>u.href),failed:records.filter(r=>r.status!==200).map(r=>({url:r.url,status:r.status,warning:r.warning}))};const temp=manifestPath+'.tmp';await fs.writeFile(temp,JSON.stringify(body,null,2));await fs.rename(temp,manifestPath)}
add(start);for(const r of previous?.records||[])add(normalize(r.url,start));for(const url of previous?.pending||[])add(normalize(url,start));
console.log('V3断点续采：仅采集公开本站链接，请求间隔至少800毫秒。最多',max,'个文件。');
if(previous)console.log('检测到旧记录，将复用已保存文件，并继续处理剩余链接。');
for(let i=0;i<queue.length&&!stopped;i++){
 const u=queue[i],file=name(u),target=path.join(raw,file),old=cached.get(u.href);console.log(`[${i+1}/${queue.length}] ${u.href}`);
 try{
  if(old?.status===404||old?.status==='unavailable-media'){remember(old);continue}
  let buffer=null,r=null;const reusable=old?.status===200&&old.file===file;
  if(reusable){try{buffer=await fs.readFile(target);r={status:200,type:old.type||''}}catch{}}
  if(!r){
   if(!await permitted(u)){remember({url:u.href,status:'robots-excluded'});continue}
   await sleep();r=await request(u,target);
   if([401,403,429].includes(r.status)){
    remember({url:u.href,status:r.status});stopped=true;stopReason='访问限制或限流 HTTP '+r.status;console.log(stopReason+'，停止采集，不尝试绕过。');continue;
   }
   if(r.status>=500){
    console.log('服务器单文件错误，等待3秒后重试一次：',r.status);await new Promise(resolve=>setTimeout(resolve,3000));r=await request(u,target);
    if([401,403,429].includes(r.status)){remember({url:u.href,status:r.status});stopped=true;stopReason='重试收到访问限制 HTTP '+r.status;continue}
    if(r.status>=500){consecutiveFailures++;remember({url:u.href,status:r.status});console.log('记录失败，继续其他公开链接。');if(consecutiveFailures>=3){stopped=true;stopReason='连续3个资源服务器错误，暂停以避免增加负担'}continue}
   }
   consecutiveFailures=0;
   if(r.status>=300&&r.status<400&&r.location){const next=normalize(r.location,u);add(next);if(next&&allowed.has(next.hostname))await fs.writeFile(path.join(site,file),`<meta charset="utf-8"><a href="./${name(next)}">进入页面</a><script>location.replace(${JSON.stringify('./'+name(next))})</script>`);remember({url:u.href,status:r.status,redirect:next?.href,file});continue}
   if(r.status!==200){remember({url:u.href,status:r.status});continue}
   buffer=await fs.readFile(target);
  }
  total+=buffer.length;if(total>500*1024*1024){stopped=true;stopReason='达到500MB总量上限';continue}
  if(/\.(?:mp3|mp4|mid|midi|swf|wav|wma)(?:$|\?)/i.test(u.pathname)&&/html/i.test(r.type)){remember({url:u.href,file,status:'unavailable-media',type:r.type,bytes:buffer.length,warning:'媒体链接实际返回HTML，未获得真实音视频文件'});await fs.rm(path.join(site,file),{force:true});console.log('媒体返回HTML占位页，不计为采集成功。');continue}
  const html=/html/i.test(r.type)||/\.html?$/i.test(file),css=/css/i.test(r.type)||file.endsWith('.css');
  await fs.writeFile(path.join(site,file),html||css?transform(decode(buffer,r.type),u,html):buffer);
  remember({url:u.href,file,status:200,type:r.type,bytes:buffer.length});
 }catch(e){remember({url:u.href,status:'error',error:e.message});console.log('读取失败：',e.message);if(++consecutiveFailures>=3){stopped=true;stopReason='连续3个网络错误，暂停，请检查网络后重新运行'}}
 finally{await checkpoint()}
}
await checkpoint();
console.log('\n本轮结束。成功文件：',records.filter(r=>r.status===200).length,'。失败或缺失：',records.filter(r=>r.status!==200).length,'。待处理：',queue.filter(u=>!processed.has(u.href)).length);
if(stopped)console.log('暂停原因：',stopReason);if(limitReached)console.log('已达到链接发现上限，并非完整备份；请将manifest发给我继续核对。');
console.log('输出目录：',out,'。请保留output文件夹，重新运行会断点续采。完成后压缩output发给我。');

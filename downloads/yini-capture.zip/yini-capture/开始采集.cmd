@echo off
chcp 65001 >nul
cd /d "%~dp0"
node --version
if errorlevel 1 goto missing
node capture.mjs
pause
exit /b
:missing
echo 请先安装 Node.js 24 或更高版本，再重新打开本工具。
pause

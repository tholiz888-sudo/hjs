import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createCheckpointStore} from './checkpoint-store.mjs';
import {validateMp3} from './music-validation.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),out=path.join(root,'output');
const store=createCheckpointStore(path.join(out,'manifest.json')),snapshot=await store.read();
if(!snapshot)throw Error('请把已有output文件夹放在工具目录，再运行音乐补采。');
const manifest=snapshot.data,origin=new URL(manifest.start),run=promisify(execFile),referers=new Map(),report=[];
const one=process.argv.includes('--one'),pause=()=>new Promise(r=>setTimeout(r,1000));
// Only existing MP3 records are fetched; do not crawl unrelated pages.
for(const r of manifest.records){
 if(r.status!==200||!/html/i.test(r.type||'')||!r.file)continue;
 try{const bytes=await fs.readFile(path.join(out,'original',path.basename(r.file)));const text=bytes.toString('latin1');for(const match of text.matchAll(/["']([^"'<>\r\n]+\.mp3(?:\?[^"'<>\r\n]*)?)["']/gi)){try{const u=new URL(match[1].replace(/&amp;/g,'&'),r.url);if(u.origin===origin.origin&&!referers.has(u.href))referers.set(u.href,r.url)}catch{}}}catch{}
}
const target=new URL('/club/love.mp3',origin).href;
const items=manifest.records.filter(r=>/\.mp3$/i.test(new URL(r.url).pathname)&&(!one||r.url===target)&&r.status!==200);
if(!items.length){console.log(one?'love.mp3没有待补采记录（可能已经成功保存）。':'没有尚待补采的MP3记录。');process.exit(0)}
await fs.mkdir(path.join(out,'music-check'),{recursive:true});
async function request(url,file,{referer,range=false}={}){
 const header=file+'.headers',args=['--globoff','--silent','--show-error','--connect-timeout','12','--max-time','90','--max-filesize','20971520','--dump-header',header,'--output',file,'--user-agent','PublicPageArchive/1.0 (public audio verification)'];
 if(process.env.CAPTURE_PROXY)args.push('--proxy',process.env.CAPTURE_PROXY);
 if(referer)args.push('--referer',referer);
 if(range)args.push('--range','0-');args.push(url);
 await pause();await run(process.platform==='win32'?'curl.exe':'curl',args,{windowsHide:true,maxBuffer:1024*1024});
 const blocks=(await fs.readFile(header,'utf8')).trim().split(/\r?\n\r?\n/),h=blocks.at(-1);return{status:Number(h.match(/^HTTP\/\S+\s+(\d+)/i)?.[1]),type:h.match(/^content-type:\s*(.+)/im)?.[1]?.trim()||'',contentRange:h.match(/^content-range:\s*(.+)/im)?.[1]?.trim()||''};
}
function robotRules(text){const groups=[];let agents=[],rules=[],hasRules=false;function flush(){if(agents.length)groups.push({agents,rules});agents=[];rules=[];hasRules=false}for(const line of text.split(/\r?\n/)){const m=line.split('#')[0].trim().match(/^([^:]+):\s*(.*)$/);if(!m)continue;const k=m[1].toLowerCase(),v=m[2].trim();if(k==='user-agent'){if(hasRules)flush();agents.push(v.toLowerCase())}else if(['allow','disallow'].includes(k)&&agents.length){hasRules=true;if(v)rules.push({allow:k==='allow',value:v})}}flush();const own=groups.filter(g=>g.agents.some(a=>a!=='*'&&'publicpagearchive'.includes(a)));return(own.length?own:groups.filter(g=>g.agents.includes('*'))).flatMap(g=>g.rules)}
const robotsFile=path.join(out,'music-check','robots.txt');const robotResponse=await request(new URL('/robots.txt',origin).href,robotsFile);
if(robotResponse.status!==200&&robotResponse.status!==404){console.log('robots.txt无法核对，停止补采：HTTP',robotResponse.status);process.exit(1)}
const rules=robotResponse.status===200?robotRules(await fs.readFile(robotsFile,'utf8')):[];
function permitted(url){const u=new URL(url),p=u.pathname+u.search;let chosen=null;for(const r of rules){const end=r.value.endsWith('$'),pattern=r.value.replace(/\$$/,'').split('*').map(v=>v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('.*');if(new RegExp('^'+pattern+(end?'$':'')).test(p)&&(!chosen||r.value.length>chosen.value.length||r.value.length===chosen.value.length&&r.allow))chosen=r}return!chosen||chosen.allow}
let succeeded=0,failures=0;
console.log(one?'仅测试love.mp3，不重采网页和图片。':'补采清单中缺失的MP3，不重采网页和图片。');
for(const r of items){
 const u=new URL(r.url);if(u.origin!==origin.origin||!permitted(r.url)){report.push({url:r.url,status:'skipped-policy'});continue}
 const referer=referers.get(r.url)||(r.url===target?new URL('/club/garden.html',origin).href:new URL('./',u).href);
 const filename=r.file&&path.basename(r.file)===r.file?r.file:createHash('sha256').update(r.url).digest('hex').slice(0,24)+'.mp3';
 const temporary=path.join(out,'music-check',filename+'.download');console.log(`[${report.length+1}/${items.length}] ${r.url} 来源页面：${referer}`);
 let stop=false;
 try{
  const response=await request(r.url,temporary,{referer,range:true});
  if([401,403,429].includes(response.status)){report.push({url:r.url,...response,reason:'访问限制或限流，停止，不绕过'});stop=true}
  else{
   const bytes=await fs.readFile(temporary),check=validateMp3(bytes,response);report.push({url:r.url,referer,...response,bytes:bytes.length,...check});
   if(check.ok){await fs.copyFile(temporary,path.join(out,'original',filename));await fs.copyFile(temporary,path.join(out,'site',filename));Object.assign(r,{file:filename,status:200,type:'audio/mpeg',bytes:bytes.length,musicVerifiedAt:new Date().toISOString(),referer});delete r.warning;delete r.error;succeeded++;failures=0;console.log('成功：完整MP3，',bytes.length,'字节。')}
   else{failures++;console.log('尚未取得音频：',check.reason)}
  }
 }catch(error){failures++;report.push({url:r.url,reason:error.message});console.log('请求失败，记录到音乐报告。')}
 finally{
  await fs.rm(temporary,{force:true});await fs.rm(temporary+'.headers',{force:true});
  await fs.writeFile(path.join(out,'music-report.json'),JSON.stringify({at:new Date().toISOString(),items:report},null,2));
  manifest.at=new Date().toISOString();manifest.bytes=manifest.records.filter(x=>x.status===200).reduce((n,x)=>n+(x.bytes||0),0);manifest.failed=manifest.records.filter(x=>x.status!==200).map(x=>({url:x.url,status:x.status,warning:x.warning}));
  const saved=await store.write(manifest);if(!saved.published)console.log('正式清单被占用，进度保存在恢复文件：',path.basename(saved.file));
 }
 if(stop||failures>=3){console.log('已暂停，避免连续请求失败。请发output/music-report.json给我核对。');break}
}
console.log('本轮成功取得',succeeded,'首。请把output/music-report.json发给我。');
